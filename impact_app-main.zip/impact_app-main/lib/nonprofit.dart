import 'package:flutter/material.dart';
class Nonprofits {
  Nonprofits(this.org, this.impact, this.color);
  final String org;
  final int impact;
  final Color color;
}